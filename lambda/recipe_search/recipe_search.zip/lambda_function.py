import json
import boto3
from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth

lex_client = boto3.client('lex-runtime')

credentials = boto3.Session().get_credentials()
region = 'us-east-1'
service = 'es'
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

def lambda_handler(event, context):
    
    
    print("DEBUG: event:", event) # 'queryStringParameters': {'q': 'apple'} # will need to set up the API Gateway to get this kind of query
    # this is smiliar to GET of Assginment 2
    user_message = event['queryStringParameters']['q'] # 'apple'
    # have the query message to be trimmed and lowercased in frontend javascript (ex.document.getElementById("XXXX").value.trim().toLowerCase())

    if user_message == None:
        return{
            'statusCode': 200,
            'headers': { 
                'Access-Control-Allow-Headers' : 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,GET'
            },
            'body':json.dumps("No Message!")
        }

    # dont put lex here as we did on assignment 2

    es_endpoint = 'NOT YET MADE'
    es = Elasticsearch(
        hosts = [{'host': es_endpoint, 'port': 443}],
        http_auth = awsauth,
        use_ssl = True,
        verify_certs = True,
        connection_class = RequestsHttpConnection
    )

    # when saving onto es, combine cuisine, name, ingredient as the search term
    # for name, name.split(" ")
    es_search_result = es.search(index = "images", body = {
        "query":{
            'match':{
                'labels': user_message
            }}})

    ##with the es_search_results go find details from dynamoDB